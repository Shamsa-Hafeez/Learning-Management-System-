from datetime import date
from flask import Flask , render_template, request, redirect 
from flask_mysqldb import MySQL
import yaml 

app = Flask(__name__)

#Configure Database
db = yaml.load(open('db.yaml'))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']

mysql = MySQL(app)


@app.route('/', methods=['GET', 'POST'])

def index():
    if request.method == 'POST':

        #fetch the form data
        studentDetails = request.form
        st_id = studentDetails['st_id']
        Name = studentDetails['name']
        DOB = studentDetails['DOB']

        # Run the query
        cur = mysql.connection.cursor() 
        cur.execute("INSERT INTO students(st_id,Name,DOB) VALUES(%s,%s,%s)",(st_id,Name,DOB)) 
        mysql.connection.commit()
        cur.close() 

        return redirect('/students')
    return render_template('index.html')
    
@app.route('/students', methods=['GET', 'POST'])

def users():  
    cur = mysql.connection.cursor() 
    resultValue = cur.execute("SELECT * from students")
    
    if resultValue > 0: 
        userDetails = cur.fetchall()

        if request.method == 'POST':

            # Throw an error if date is not entered 
            new = request.form['my_date']
            if new == "":
                return render_template('error.html',userDetails=userDetails)
             
            # Throw an error if the attendance of atleast one student is not marked 
            for i in range(resultValue):
                try: 
                    at_entry = request.form[userDetails[i][1]]
                except:
                    return render_template('entry_error.html',userDetails=userDetails)
                
                cur = mysql.connection.cursor()
                cur.execute("INSERT INTO attendance(date,st_id,status) VALUES(%s,%s,%s)",(new,userDetails[i][0],at_entry)) 
                mysql.connection.commit()
                cur.close() 

        return render_template('students.html',userDetails=userDetails)

    return "Hello World"
    


if __name__ == "__main__":
	app.run(debug=True) 