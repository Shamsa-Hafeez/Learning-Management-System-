# from crypt import methods
# from crypt import methods
from flask import Flask , render_template, request, redirect 
from flask_mysqldb import MySQL
import yaml 

app = Flask(__name__)

#Configure DB
db = yaml.load(open('db.yaml'))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']

mysql = MySQL(app)


@app.route('/', methods=['GET', 'POST'])

def index():
    if request.method == 'POST':
        #fetch the form data
        studentDetails = request.form
        st_id = studentDetails['st_id']
        Name = studentDetails['name']
        DOB = studentDetails['DOB']
        cur = mysql.connection.cursor() 
        cur.execute("INSERT INTO students(st_id,Name,DOB) VALUES(%s,%s,%s)",(st_id,Name,DOB)) 
        mysql.connection.commit()
        cur.close() 
        return redirect('/students')
    return render_template('index.html')
    
@app.route('/students')
def users():    
    cur = mysql.connection.cursor() 
    resultValue = cur.execute("SELECT * from students")
    if resultValue > 0: 
        userDetails = cur.fetchall()
        return render_template('students.html',userDetails=userDetails)

    
@app.route('/attendance',methods=['GET', 'POST'])
def attendance():    
    cur = mysql.connection.cursor() 
    resultValue = cur.execute("SELECT * from students")
    userDetails = cur.fetchall()

    # if request.method == 'POST':
        
    #     attendanceDetails = request.form
    #     st_id = attendanceDetails['st_id']
    
        
    #     date = attendanceDetails['at_date']
        
    #     status = attendanceDetails['options']
       
    #     cur = mysql.connection.cursor() 
    #     cur.execute("INSERT INTO ATTENDENCE(st_id,date,st_id,status) VALUES(%s,%s,%s,%s)",(st_id,date,st_id,status)) 
    #     mysql.connection.commit()
    #     cur.close() 
    print("done..............")
    #     return redirect('/attendance')
    return render_template('students.html',userDetails=userDetails)

@app.route('/attendance',methods=['GET', 'POST'])
def ct_edit(st_id):
    print("=======================")
    return "success"
    print('ct_edit')
    # the value of the first column of the selected row => ID
    # do something with the ID value and get a result
    return render_template('ct_edit.html', result=result) 

if __name__ == "__main__":
	app.run(debug=True) 