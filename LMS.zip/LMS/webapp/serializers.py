from dataclasses import field
from statistics import mode
from attr import fields
from rest_framework import serializers
from .models import students  

class studentSerializer(serializers.ModelSerializer):
    class Meta:
        model = students
        #fields = ('st_id', 'firstName', 'lastName')
        fields = '__all__'