from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import students
from .serializers import studentSerializer
from rest_framework.decorators import api_view



class studentsList(APIView):
    def get(self, request):
        students1 = students.objects.all() 
        serializer = studentSerializer(students1, many=True)
        return Response(serializer.data)

    def post(self): 
        pass  