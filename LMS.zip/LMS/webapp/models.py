from pyexpat import model
from django.db import models
from django.forms import IntegerField

# Create your models here.
class students(models.Model):
    firstName = models.CharField(max_length=10,null=False,blank=False)
    lastName = models.CharField(max_length=10,null=False,blank=False)
    st_id = models.IntegerField() 
    class_no = models.IntegerField() 
    section = models.CharField(max_length=1,null=False,blank=False)

    def __str__(self): 
        return self.firstName + " " + self.lastName